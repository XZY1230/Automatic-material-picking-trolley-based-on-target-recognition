#ifndef __SERVO_H
#define __SERVO_H
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "control.h"
void Servo_Init(void);
void Servo_slow(u8 Servo_x, uint16_t position_1,uint16_t position_2, u8 time);
void Servo_slow_two( uint16_t position_1,uint16_t position_2,uint16_t position_3,uint16_t position_4, u8 time);
#endif
