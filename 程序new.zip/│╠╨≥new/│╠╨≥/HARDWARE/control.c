#include "control.h"
#include "delay.h"
#include "timer.h"
#include "usart.h"
#include "motor.h"
#include "servo.h"
uint16_t ball[3][2]={ {1500,1000}, //��ʼ��״̬
											{1980,1000}, //ץȡ״̬
											{1500,1400},//����״̬
											};  //�ֱ��Ӧ���1 3��ռ�ձȣ�4�Ŷ��Ϊצ�ӣ��������ƣ�2���¼ӵ�
vu8 sta1=0,sta2=0;  //״̬1����ץȡ����״̬2��ץȡ����־λ����1˵���ﵽ��״̬

void Find_ball_STA1()//��һ������״̬
{
	if(abs(cx,(STA1_X_MIN+STA1_X_MAX)/2)*2>abs(cy,(STA1_Y_MIN+STA1_Y_MAX)/2)) //��������ȵ�x�ٵ�y
	{
		if(cx<STA1_X_MIN || cx>STA1_X_MAX)  //�ȵ�X
		{
			if(cx>STA1_X_MAX)
			{
				Motor_turn_left(STA1_SPEED);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_turn_right(STA1_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}
		else if(cy<STA1_Y_MIN || cy>STA1_Y_MAX)  //�ٵ�Y
		{
			if(cy>STA1_Y_MAX)
			{
				Motor_go_stright(STA1_SPEED);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_go_back(STA1_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}
		else  //�������
		{
			sta1=1;//״̬1���
			delay_ms(500);
			Servo_slow(1,ball[0][0],ball[1][0],1);
			Servo_slow(3,ball[0][1],ball[1][1],1);//���ƶ��ת��Ϊ״̬2
		}
	}
	else      //��������ȵ�y�ٵ�x
	{
		if(cy<STA1_Y_MIN || cy>STA1_Y_MAX)  //�ȵ�Y
		{
			if(cy>STA1_Y_MAX)
			{
				Motor_go_stright(STA1_SPEED);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_go_back(STA1_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}
		else if(cx<STA1_X_MIN || cx>STA1_X_MAX)  //�ٵ�X
		{
			if(cx>STA1_X_MAX)
			{
				Motor_turn_left(9);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_turn_right(STA1_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}

		else
		{
			sta1=1;//״̬1���
			delay_ms(500);
			Servo_slow(1,ball[0][0],ball[1][0],1);
			Servo_slow(3,ball[0][1],ball[1][1],1);//���ƶ��ת��Ϊ״̬1
			delay_ms(500);
		}
	}
}


void Find_ball_STA2()//�ڶ�������״̬
{
	if(abs(cx,(STA2_X_MIN+STA2_X_MAX)/2)>abs(cy,(STA2_Y_MIN+STA2_Y_MAX)/2)*2) //��������ȵ�x�ٵ�y
	{
		if(cx<STA2_X_MIN || cx>STA2_X_MAX)  //�ȵ�X
		{
			if(cx>STA2_X_MAX)
			{
				Motor_turn_left(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_turn_right(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}
		else if(cy<STA2_Y_MIN || cy>STA2_Y_MAX)  //�ٵ�Y
		{
			if(cy>STA2_Y_MAX)
			{
				Motor_go_stright(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_go_back(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}
		else
		{
			sta2=1;//״̬2���
			delay_ms(500);
			get_width=1;
			delay_ms(100);
			get_width=0;
			delay_ms(100);
			width_ave/=m;
		}
	}
	else                            //��������ȵ�y�ٵ�x
	{
		if(cy<STA2_Y_MIN || cy>STA2_Y_MAX)  //�ȵ�Y
		{
			if(cy>STA2_Y_MAX)
			{
				Motor_go_stright(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_go_back(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}
		
		else if(cx<STA2_X_MIN || cx>STA2_X_MAX)  //�ٵ�X
		{
			if(cx>STA2_X_MAX)
			{
				Motor_turn_left(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
			else
			{
				Motor_turn_right(STA2_SPEED);
				delay_ms(2);
				Motor_stop();
			}
		}
		else
		{
			sta2=1;//״̬2���
			delay_ms(500);
			get_width=1;
			delay_ms(100);
			get_width=0;
			delay_ms(100);
			width_ave/=m;
		}
	}

}

void Catch_ball(void)
{
	TIM_SetCompare4(TIM3,CATCH_PWM);  //4�Ŷ��ץȡ
	width_ave=0;m=0;
	delay_ms(500);
	Servo_slow(1,ball[1][0],ball[2][0],1);
	Servo_slow(3,ball[1][1],ball[2][1],1);  //����
	delay_ms(300);
	Servo_slow(2,SERVO2INIT,SERVO2BACK,1);  //����
	delay_ms(300);
	TIM_SetCompare4(TIM3,PUT_PWM);  //4�Ŷ���ɿ�
	delay_ms(300);
	Servo_slow(2,SERVO2BACK,SERVO2INIT,1);
	Servo_slow(1,ball[2][0],ball[0][0],1);  //�ع��ʼ��
	Servo_slow(3,ball[2][1],ball[0][1],1);
	delay_ms(300);
	TIM_SetCompare4(TIM3,1700);  //����
	delay_ms(300);
	TIM_SetCompare4(TIM3,1300);  //����
	delay_ms(200);
	TIM_SetCompare4(TIM3,1700);  //����
	delay_ms(200);
	TIM_SetCompare4(TIM3,1300);  //����
	delay_ms(200);
	TIM_SetCompare4(TIM3,1700);  //����
	delay_ms(200);
	TIM_SetCompare4(TIM3,PUT_PWM);  //�س�ʼ��
	delay_s(1);
	sta1=0;
	sta2=0;  //��״̬��־��0
}

void Patrol(void)//�������Ѳ�ߺ���
{
	u8 temp;
	Motor_go_stright(GO_SPEED);
	while(1)
	{
		temp=0;
		while(temp<20)
		{
			temp++;
			if(!nothing||obstacle)
			{
				Motor_stop();
				return;
			}
			delay_ms(10);
		}
		Servo_slow(2,SERVO2INIT,SERVO2RIGHT,1);//�ҿ���
		temp=0;
		while(temp<20)
		{
			temp++;
			if(!nothing)
			{
				Motor_turn_right(TURN_SPEED);
				Servo_slow(2,SERVO2RIGHT,SERVO2INIT,4);
				Motor_stop();
				return;
			}
			if(obstacle)
			{
				Motor_stop();
				Servo_slow(2,SERVO2RIGHT,SERVO2INIT,1);
				return;
			}
			delay_ms(10);
		}
		Servo_slow(2,SERVO2RIGHT,SERVO2INIT,1);
		temp=0;
		while(temp<20)
		{
			temp++;
			if(!nothing||obstacle)
			{
				Motor_stop();
				return;
			}
			delay_ms(10);
		}
		Servo_slow(2,SERVO2INIT,SERVO2LEFT,1);//�󿴿�
		temp=0;
		while(temp<20)
		{
			temp++;
			if(!nothing)
			{
				Motor_turn_left(TURN_SPEED);
				Servo_slow(2,SERVO2LEFT,SERVO2INIT,4);
				Motor_stop();
				return;
			}
			if(obstacle)
			{
				Motor_stop();
				Servo_slow(2,SERVO2LEFT,SERVO2INIT,1);
				return;
			}
			delay_ms(10);
		}
		Servo_slow(2,SERVO2LEFT,SERVO2INIT,1);
	}
}

void dancing1()
{
	TIM_SetCompare1(TIM3,ball[0][0]);	
	TIM_SetCompare2(TIM3,SERVO2INIT);
	TIM_SetCompare3(TIM3,1500);				//  ̧ͷ
	TIM_SetCompare4(TIM3,PUT_PWM);
	delay_ms(500);
	Servo_slow(2,SERVO2INIT,SERVO2RIGHT,1);
	Servo_slow(3,1500,900,1);         //�Ϲ�
	delay_ms(200);
	Servo_slow(3,900,1500,1);
	delay_ms(500);
	Servo_slow(2,SERVO2RIGHT,SERVO2LEFT,1);
	Servo_slow(3,1500,900,1);
	delay_ms(200);
	Servo_slow(3,900,1500,1);
	delay_ms(500);
	Servo_slow(2,SERVO2LEFT,SERVO2INIT,1);
	Servo_slow(3,1500,900,1);         //�Ϲ�
	delay_ms(200);
	Servo_slow(3,900,ball[0][1],1);
}
void dancing2()
{
	TIM_SetCompare1(TIM3,ball[0][0]);	//��ʼ��
	TIM_SetCompare2(TIM3,SERVO2INIT);
	TIM_SetCompare3(TIM3,ball[0][1]);	
	TIM_SetCompare4(TIM3,PUT_PWM);
	
	Servo_slow(1,ball[0][0],1100,2);
	Servo_slow(3,ball[0][1],900,2);
	Servo_slow_two(SERVO2INIT,SERVO2RIGHT,PUT_PWM,CLAP_CLOSE,1); // ��һ������
	Servo_slow_two(SERVO2RIGHT,SERVO2INIT,CLAP_CLOSE,CLAP_OPEN,1);
	Servo_slow_two(SERVO2INIT,SERVO2LEFT,CLAP_OPEN,CLAP_CLOSE,1);
	Servo_slow_two(SERVO2LEFT,SERVO2INIT,CLAP_CLOSE,CLAP_OPEN,1);
	Servo_slow_two(SERVO2INIT,SERVO2RIGHT,PUT_PWM,CLAP_CLOSE,1); // ��һ������
	Servo_slow_two(SERVO2RIGHT,SERVO2INIT,CLAP_CLOSE,CLAP_OPEN,1);
	Servo_slow_two(SERVO2INIT,SERVO2LEFT,CLAP_OPEN,CLAP_CLOSE,1);
	Servo_slow_two(SERVO2LEFT,SERVO2INIT,CLAP_CLOSE,CLAP_OPEN,1);
	Servo_slow_two(SERVO2INIT,SERVO2RIGHT,PUT_PWM,CLAP_CLOSE,1);  //�ڶ���
	Servo_slow_two(SERVO2RIGHT,SERVO2INIT,CLAP_CLOSE,CLAP_OPEN,1);
	Servo_slow_two(SERVO2INIT,SERVO2LEFT,CLAP_OPEN,CLAP_CLOSE,1);
	Servo_slow_two(SERVO2LEFT,SERVO2INIT,CLAP_CLOSE,PUT_PWM,1);   //�ָ�����ʼ��״̬
	
	Servo_slow(1,1100,ball[0][0],2);
	Servo_slow(3,900,ball[0][1],2);

	
}

u8 abs(u8 a1,u8 a2)
{
	if(a1>a2)
		return a1-a2;
	else
		return a2-a1;
}



