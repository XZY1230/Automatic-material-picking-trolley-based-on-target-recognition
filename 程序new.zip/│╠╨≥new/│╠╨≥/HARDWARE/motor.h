#ifndef __MOTOR_H
#define __MOTOR_H
#include "sys.h"
#include "delay.h"
#include "usart.h"

void Motor_Init(void);
void Motor_stop(void);
void Motor_go_stright(u16 speed);
void Motor_turn_right(u16 speed);
void Motor_turn_left(u16 speed);
void Motor_go_back(u16 speed);
void Go_down(void);
#endif
